import ExpoModulesCore

public class ExpoDevcheckModule: Module {
  public func definition() -> ModuleDefinition {
    Name("ExpoDevcheck")

    AsyncFunction("isDeveloperOptionsEnabled") { () -> Bool in
      return false // iOS doesn't expose such a toggle
    }
  }
}