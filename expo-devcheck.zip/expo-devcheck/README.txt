expo-devcheck (local module)

WHAT IT DOES
------------
Exposes a single async function to JS:
  isDeveloperOptionsEnabled(): Promise<boolean>

On Android, it returns TRUE if the system Developer Options toggle is enabled
(checked in both Settings.Global and Settings.Secure).
On iOS, it always returns FALSE (no equivalent public toggle).

HOW TO INSTALL (in your Expo app root)
--------------------------------------
1) Copy the 'expo-devcheck' folder to your project root.
2) Add the dependency in package.json:
     "expo-devcheck": "file:./expo-devcheck"
3) Install deps:
     npm install
4) Prebuild Android (required because this adds native code):
     npx expo prebuild -p android
5) Build a production binary (EAS or local Gradle).

USAGE (App.js)
--------------
import { isDeveloperOptionsEnabled } from 'expo-devcheck';
import * as Device from 'expo-device';
import Constants from 'expo-constants';
import { BackHandler, Platform } from 'react-native';

(async () => {
  const notStandalone = Constants.appOwnership !== 'standalone';
  const isJsDev = __DEV__;
  const isEmulator = !Device.isDevice;

  let sysDevOptions = false;
  if (Platform.OS === 'android') {
    try { sysDevOptions = await isDeveloperOptionsEnabled(); } catch {}
  }

  const shouldBlock = notStandalone || isJsDev || isEmulator || sysDevOptions;
  if (shouldBlock && Platform.OS === 'android') {
    BackHandler.exitApp();
  }
})();

NOTES
-----
- Whenever you change files inside expo-devcheck/android, run prebuild again.
- You must have 'expo-modules-core' in your app (Expo SDK brings it).
- No changes to MainApplication are needed; Expo Modules autolinking handles it.