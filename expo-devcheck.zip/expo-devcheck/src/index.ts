import { requireNativeModule } from 'expo-modules-core';

type Native = {
  isDeveloperOptionsEnabled: () => Promise<boolean>;
};

const Devcheck = requireNativeModule<Native>('ExpoDevcheck');

export async function isDeveloperOptionsEnabled(): Promise<boolean> {
  return Devcheck.isDeveloperOptionsEnabled();
}