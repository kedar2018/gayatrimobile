package com.expodevcheck

import android.provider.Settings
import expo.modules.kotlin.modules.Module
import expo.modules.kotlin.modules.ModuleDefinition

class DevcheckModule : Module() {
  override fun definition() = ModuleDefinition {
    Name("ExpoDevcheck")

    AsyncFunction("isDeveloperOptionsEnabled") {
      val ctx = appContext.reactContext ?: appContext.currentActivity ?: throw IllegalStateException("No context")
      val cr = ctx.contentResolver

      val enabledGlobal = try {
        Settings.Global.getInt(cr, Settings.Global.DEVELOPMENT_SETTINGS_ENABLED, 0) != 0
      } catch (_: Throwable) { false }

      val enabledSecure = try {
        Settings.Secure.getInt(cr, "development_settings_enabled", 0) != 0
      } catch (_: Throwable) { false }

      enabledGlobal || enabledSecure
    }
  }
}